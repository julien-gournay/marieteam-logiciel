package fr.marieteamclient.models;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class Bateau {

}
